#!/usr/local/bin/bash

OUTPUT=$1
shift
first=1
for FILE in $@
do
	if [ "$first" == "1" ]; then
		cat $FILE > combineascii.tmp
	else
		cat $FILE | sed '1d' >> combineascii.tmp
	fi
	first=0
done
mv combineascii.tmp $OUTPUT
