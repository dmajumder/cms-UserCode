#!/usr/local/bin/bash

################################################
# SET DEFAULTS
################################################

QUEUE=8nm
NUMBERJOBS=1
RUN_DIR=/afs/cern.ch/user/d/devdatta/scratch0/BaurWgamGenerator
#Where the wgam executable is
BIN_DIR=/afs/cern.ch/user/d/devdatta/scratch0/BaurWgamGenerator/bin
DO_CLEAN=0
MINIMUM_EVENTS=9999999

################################################
# READ COMMAND LINE ARGUMENTS OR PRINT HELP
################################################

if [ -z $1 ]
# Only print help menu if no argument(s) given.
then
  cat << HERE 
Usage: `basename $0` [OPTIONS] DATACARD_FILENAME

Set up and run the wgam generator using batch jobs, with either single or split
datacards. DATACARD_FILENAME is the name of the datacard to use.

If it ends merely with .txt it is considered to be a normal datacard.

If it ends with .template.txt it is considered to be a split datacard, and the
corresponding .completions.txt file is also searched for.
If it ends with .completions.txt it is considered to be a split datacard, and
the corresponding .template.txt file is also searched for.
So in either case, only one of the pair of files needs to be specified, but
both files must exist. The completions are added to the template in turn to
form several complete datacards.

A task directory is created for each complete datacard formed. Within each task
directory job directories for the same datacard are created depending on the
multiplicity specified.
Note: Datacards containing any line anywhere that says "TASKNAME=xxx"
have their task directories given as xxx, rather than the default based on
the datacard filename. This is not a generator option. If TASKNAME= occurs
more than once in the file only the last entry is used.
If the directory xxx already exists, the new jobs are added to the
existing ones so  that run.sh can be used again and again to increase the
total 4-vector output.

OPTIONS:
-m num    Multiply job. i.e. Number of times to run the same job within each
          task, with different RandomSeed. The hbook files within each job
          directory are combined into a single hbook file in the parent task
          directory. Default is $NUMBERJOBS.
-q queue  LSF Batch queue to use for each job. Use bqueues to list those
          available. Default is $QUEUE
-r dir    Run directory. Where to make Task directories. One Task dir is set up
          for each complete datacard formed.
          Default is $RUN_DIR
-c        Clean task/job directories to remove all files except input file,
          4 vector output, and cross-section results 
-n min    Minimum events required. No jobs are submitted within a task if the
          number of events already present in the 4-vector file exceeds min.
          This does not guarantee > min events will be generated, but it saves
          submitting jobs for tasks that are at the required level.
          Default is $MINIMUM_EVENTS
HERE
  exit 1
fi  

while getopts "m:q:r:cn:" option
do
  case $option in
    m ) #Number of times to multiply job. Job data is collated into a single ntuple file
        NUMBERJOBS=$OPTARG;;
    q ) #lsf batch job queue to use
    	QUEUE=$OPTARG;;
    r ) #directory in which to create task directories
        RUN_DIR=$OPTARG;;
    c ) #clean task/job directories of less important files
        DO_CLEAN=1;;
    n ) #Minimum events required
        MINIMUM_EVENTS=$OPTARG
  esac
done
shift $(($OPTIND - 1))
DATACARD_FILENAME=$1

#######################################################
# VALIDATE INPUT
#######################################################

# Was a datacard even specified?
if [ ! $DATACARD_FILENAME ]; then
	echo 'No input datacard specified.'
	exit 1
fi

# Does the file even exist to begin with, whether full pathname or not
if [ ! -e "$DATACARD_FILENAME" ]; then
	echo 'File '$DATACARD_FILENAME' does not exist'
	exit 1
fi

# Find fullpath name
thisdir=`pwd`
cd `dirname $DATACARD_FILENAME`
DATACARD_FILENAME=`pwd`/`echo $DATACARD_FILENAME | sed 's%.*/%%'`
cd $thisdir
DATACARD_FULLSTEM=`echo $DATACARD_FILENAME | sed 's/.txt//'`

IS_SPLIT=`false`

if [ `echo $DATACARD_FILENAME | grep .completions.txt` ]; then
  DATACARD_FULLSTEM=`echo $DATACARD_FILENAME | sed 's/.completions.txt//'`
  IS_SPLIT=1
fi
if [ `echo $DATACARD_FILENAME | grep .template.txt` ]; then
  DATACARD_FULLSTEM=`echo $DATACARD_FILENAME | sed 's/.template.txt//'`
  IS_SPLIT=1
fi

DATACARD_STEM=`echo $DATACARD_FULLSTEM | sed 's%.*/%%'`

#echo $DATACARD_FILENAME
#echo $DATACARD_FULLSTEM
#echo $DATACARD_STEM

if [ $IS_SPLIT ]; then
	echo 'Split datacard.'
	if [ ! -e "$DATACARD_FULLSTEM.template.txt" ]; then
	  	if [ ! -e "$DATACARD_FULLSTEM.completions.txt" ]; then
			echo 'Input datacards '$DATACARD_FULLSTEM'.template.txt' and '$DATACARD_FULLSTEM'.completions.txt' do not exist.'
			exit 1
		fi
	fi
	if [ -e "$DATACARD_FULLSTEM.template.txt" ]; then
  		if [ ! -e "$DATACARD_FULLSTEM.completions.txt" ]; then
			echo $DATACARD_FULLSTEM'.template.txt has no corresponding file '$DATACARD_FULLSTEM'.completions.txt'
			exit 1
		fi
	else
  		if [ -e "$DATACARD_FULLSTEM.completions.txt" ]; then
			echo $DATACARD_FULLSTEM'.completions.txt has no corresponding file '$DATACARD_FULLSTEM'.template.txt'
			exit 1
		fi
	fi
else
	echo 'Normal datacard.'
fi

##########################################################

#Usage: combineascii <outputfile> <input1> <input2> ...
#Combines tabulated ascii files, where each file has one column header
function combineascii  {
OUTPUT=$1
shift
first=1
for FILE in $@
do
        if [ "$first" == "1" ]; then
                cat $FILE > $OUTPUT
        else
                cat $FILE | sed '1d' >> $OUTPUT
        fi
        first=0
done
}

##########################################################
#Usage: combinehbook <outputfile> <input1> <input2> ...
#Wraps the hbookmerge mini program in this package so that it can 
#process multiple files with any length filename, and so that an input file
#can also be used as the output file
function combinehbook {
ofile=$1
shift
tmp=hbtmp
tmpout=hbtmpo1
tmpout2=hbtmpo2
list=hblisttmp
num=0
for ifile in $*
do
	echo file $num $ifile
	if [ $num == 0 ]; then
		#Simply copy the first input file to the output file
		cp $ifile $tmpout
	else
		#For subsequent input files hbookmerge them with the
		#output file
		
		#Fortran HMERGE routine has an 8 character limit on filenames
		#So have to copy hbook file to shorter named file first
		cp $ifile $tmp
		echo $tmpout2 > $list
		echo 2 >> $list
		echo $tmp >> $list
		echo $tmpout >> $list
		$BIN_DIR/hbookmerge < $list
		rm -f $list
		rm -f $tmp
		mv $tmpout2 $tmpout
	fi
	let num=1+$num
	
done
}

##########################################################

#Usage: wgamscript <jobdir>
#Outputs a script to stdout
#capable of running a wgam job in the given directory
function wgamscript {
	JOB_DIR_FULL_PATH=$1
	cat << HERE
#!/usr/local/bin/bash
export LHAPATH=/afs/cern.ch/cms/sw/slc3_ia32_gcc323/external/lhapdf/5.2.3-cms/PDFsets
cd $JOB_DIR_FULL_PATH
$BIN_DIR/wgam
$BIN_DIR/wgam

h2root hist.hbook

lockfile ../baur.hbook.lock
if [ -f "../baur.hbook" ]; then
	$BIN_DIR/hbookmerge.sh ../baur.hbook ../baur.hbook baur.hbook
else
	cp baur.hbook ../baur.hbook
fi
rm -f ../baur.hbook.lock

lockfile ../hist.hbook.lock
if [ -f "../hist.hbook" ]; then
	$BIN_DIR/hbookmerge.sh ../hist.hbook ../hist.hbook hist.hbook
else
	cp hist.hbook ../hist.hbook
fi
rm -f ../hist.hbook.lock

lockfile ../baur.ascii.lock
if [ -f "../baur.ascii" ]; then
	$BIN_DIR/combineascii.sh ../baur.ascii ../baur.ascii baur.ascii
else
	cp baur.ascii ../baur.ascii
fi
rm -f ../baur.ascii.lock

if [ $DO_CLEAN == 1 ]; then
  rm -f *.hbook
  rm -f ../*.hbook
  rm -f fort.*
  rm -f {maxwgt,selwgt,scrtch,wgam.sh,baur.txt,baur.ascii,baur.input}
fi

HERE
}

##########################################################

# Usage: makejob <jobname>
# Make a job, by creating a directory
# and a running batch job,
# within the current directory
function makejob {
	#make a job directory from the name given
	JOB_DIR=$1
	mkdir -p $JOB_DIR
	#copy the input file into it, but append a RandomSeed statement to it if there is
	#more than one job to be run
	rm -f rndmtmp
	if [ $NUMBERJOBS = 1 ]; then
		cp baurinput.txt $JOB_DIR/baurinput.txt
	else
		sleep 1s
		echo RandomSeed=$num`date | sed -e 's/[^0-9]//g' | cut -b2-7` > rndmtmp
		cat rndmtmp baurinput.txt > $JOB_DIR/baurinput.txt
	fi
	rm -f rndmtmp
	#enter the job directory
	cd $JOB_DIR
	#and make the job script
	wgamscript $RUN_DIR/$TASK_DIR/$JOB_DIR > wgam.sh
	chmod 744 wgam.sh
	#issue the batch command
	echo '        'Job: $JOB_DIR
	JOB_OPTIONS=
	if [ $DO_CLEAN == 1 ]; then
	  JOB_OPTIONS='-o /dev/null'
	fi
	bsub -q$QUEUE $JOB_OPTIONS -J$TASK_DIR$JOB_DIR < wgam.sh
	#leave JOB_DIR
	cd ..
}

###########################################################

#Make the run dir if it doesn't already exist
mkdir -p $RUN_DIR
cd $RUN_DIR

tasknum=0

if [ ! $IS_SPLIT ]; then

	###################
	# SINGULAR DATACARD
	###################

	echo Data card is $DATACARD_FULLSTEM.txt

	if [ $(grep -c TASKNAME\= $DATACARD_FULLSTEM.txt) == 0 ];then
	  #Create a task directory with a unique number appended
	  while [ -d "$DATACARD_STEM$tasknum" ]; do
		let tasknum=$tasknum+1
	  done
	  TASK_DIR=$DATACARD_STEM$tasknum
	else
	  #Use TASKNAME entry in datacard
	  TASK_DIR=$(grep TASKNAME= $DATACARD_FULLSTEM.txt | tail -n1 | sed 's/.*TASKNAME\=//')
	fi
	echo Task: $TASK_DIR
	mkdir -p $TASK_DIR
	cd $TASK_DIR
	
	#Create the input file
	cp $DATACARD_FULLSTEM.txt baurinput.txt
	
	#Submit jobs if either the combined 4 vector file is non-existant
	#Or if it doesn't contain at least MINIMUM_EVENTS
	#Ok, well wc -l gives number of events+1, but it is close enough
	if [ ! -f baur.ascii ] || [ $(cat baur.ascii | wc -l ) -le $MINIMUM_EVENTS ]; then
	  #make jobs
 	  maxjobs=`echo $NUMBERJOBS - 1|bc`
	  num=0
	  for job in `seq 0 $maxjobs`
	  do
	    #If job directory already exists create one with the next free number
	    while [ -d "job$num" ]; do
	      let num=num+1
	    done
	  makejob job$num
	  done
	fi
	#leave TASK_DIR
	cd ..
else

	################
	# SPLIT DATACARD
	################

	echo Data card template is $DATACARD_FULLSTEM.template.txt
	echo And the completions file is $DATACARD_FULLSTEM.completions.txt
  
	exec 0<$DATACARD_FULLSTEM.completions.txt

	#Currently in RUN_DIR. So need to create a complete datacard file
	#So cycle through the completions.txt file until a * is found
	#Then append it to the template and create a task.
	rm -f tmp.txt
	touch tmp.txt
	
	while read line
	do
	if [ "$line" = "*" ]; then
	    if [ $(grep -c TASKNAME= tmp.txt) == 0 ];then
	        #Create a task directory with a unique number appended
	        while [ -d "$DATACARD_STEM$tasknum" ]; do
	    	    let tasknum=$tasknum+1
	        done
	        TASK_DIR=$DATACARD_STEM$tasknum
	    else
	      #Use TASKNAME entry in datacard
	      TASK_DIR=$( grep TASKNAME= tmp.txt | tail -n1 | sed 's/.*TASKNAME\=//')
	    fi
	    echo Task: $TASK_DIR
	    mkdir -p $TASK_DIR
	    cd $TASK_DIR
	
	    #Create the complete input file from template and completions 
	    cat ../tmp.txt $DATACARD_FULLSTEM.template.txt > baurinput.txt
 
 	    #Submit jobs if either the combined 4 vector file is non-existent
	    #Or if it doesn't contain at least MINIMUM_EVENTS
	    #Ok, well wc -l gives number of events+1, but it is close enough
	    if [ ! -f baur.ascii ] || [ $(cat baur.ascii | wc -l ) -le $MINIMUM_EVENTS ]; then
	        #make jobs
	        maxjobs=`echo $NUMBERJOBS - 1|bc`
	        num=0
	        for job in `seq 0 $maxjobs`
	        do
	          #If job directory already exists create one with the next free number:
	          while [ -d "job$num" ]; do
	            let num=num+1
	          done
		      makejob job$num
	        done
	    fi
	    #leave TASK_DIR
	    cd ..
		
	    #clean up for next one
	    rm -f tmp.txt
	    touch tmp.txt
	else
		echo $line >> tmp.txt
	fi
	done
	rm -f tmp.txt
fi



echo All jobs submitted.
echo Your run directory is $RUN_DIR


