#!/usr/local/bin/bash

BIN_DIR=/afs/cern.ch/user/d/devdatta/scratch0/BaurWgamGenerator/bin

ofile=$1
shift

tmp=hbtmp
tmpout=hbtmpo1
tmpout2=hbtmpo2
list=hblisttmp
num=0

for ifile in $*
do
	echo file $num $ifile
	if [ $num == 0 ]; then
		#Simply copy the first input file to the output file
		cp $ifile $tmpout
	else
		#For subsequent input files hbookmerge them with the
		#output file
		
		#Fortran HMERGE routine has an 8 character limit on filenames
		#So have to copy hbook file to shorter named file first
		cp $ifile $tmp
		echo $tmpout2 > $list
		echo 2 >> $list
		echo $tmp >> $list
		echo $tmpout >> $list
		$BIN_DIR/hbookmerge < $list
		rm -f $list
		rm -f $tmp
		mv $tmpout2 $tmpout
	fi
	let num=1+$num
	
done

mv $tmpout $ofile

