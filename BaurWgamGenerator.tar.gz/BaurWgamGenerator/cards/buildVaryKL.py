#Make a .completions.txt file which varies the Anomalous couplings points
 
dkV=[x/5.*1.5 for x in range(-3,4)]
lV=[y/25. for y in range(-3,4)]
dklpairs=[(dk,l) for l in lV for dk in dkV]
acdkstr=lambda dk:"AnomalousCouplingKappa="+str(dk)
aclstr=lambda l:"AnomalousCouplingLambda="+str(l)
filestr=lambda dk,l: "K_"+str(dk)+"_L_"+str(l)
#print dklpairs
for dk,l in dklpairs:
  print acdkstr(dk)+"\n"+aclstr(l)+"\n! TASKNAME="+filestr(dk,l)+"\n*"
  
#Add some additional completions so that systematic errors can be explored.
print """! Introduce a second SM dataset for use as 
! pretend dataset against the 49 calibration datasets
AnomalousCouplingKappa=0.0
AnomalousCouplingLambda=0.0
! TASKNAME=SM
*
! Introduce a non-SM dataset, that one day we'd like to be able to observe
! For example: a W boson EDM of 10^-20, predicted by, for instance, MSSM.
! For this particular case a Lambda of about 0.0001 must be observed 
AnomalousCouplingKappa=0.0
AnomalousCouplingLambda=0.0001
! TASKNAME=NonSM
*
AnomalousCouplingKappa=0.0
AnomalousCouplingLambda=0.04
TASKNAME=NonSMEasy
*
AnomalousCouplingKappa=0.0
AnomalousCouplingLambda=0.004
TASKNAME=NonSMHard
*
! Introduce a systematic error on the pdf choice (CTEQ6l instead of CTEQ5l)
LHAPDFSet=10100
! TASKNAME=SysPDF
*
! Introduce a systematic error on the infrared cutoff parameters
DELTAS = 0.04
DELTAC = 0.004
! TASKNAME=SysCutoff
*
! How about changing the dipole form factor scale
DipoleFormFactorScale=2000.
! TASKNAME=SysDFFS
*
! What about a different factorization scale choice?
FactorizationScale=1
! TASKNAME=SysScale
*"""
