BaurWgamGenerator
================

An adapted version of Ulrich Baur's Wgam generator to output unweighted
4-vector events, as well as providing utility scripts for mass-production.

Benedict J. Huckvale, Bristol University
27th May 2008


Directories
-----------

Within the package dir:

bin/ - the wgam executable. (and the hbookmerge utility)
lib/ - object files compiled from src
src/ - the fortran source files
cards/ - input datacards
Readme.txt - this file
Makefile
run.sh - script for mass production
hbookmerge.sh - helper script for hbook merging

to compile
----------

Before you start you should modify the lines at the beginning of the Makefile
to sort out the compilation directories LIB_DIR and BIN_DIR. Because one often has limited home
space at CERN, these are paths for specifying where to put the somewhat large object and executable files.
Then compilation is simple. Type:
make


wgam
----

The wgam executable created in the specified BIN_DIR, will generate a baur.hbook file of unweighted wgam nlo events which can be fed into the baur les houches interface, operating within pythia.
The directory in which it is run must contain the input datacard
named as:
baurinput.txt

To generated unweighted events two passes of the program are necessary. The first is to find the maximum weight.
If it does not already exist, a file 'maxwgt' is created
and during the program run, into this is appended the largest maximum weight as it is discovered.
This file will thus contain a history of the maximum weights
discovered.
If the file does exist i.e. during the second program run, the
largest number in the file is used as the maximum weight.
So a complete run is as follows:
wgam
wgam


run.sh
------

This is a utility class that makes it easier to run batch jobs of the wgam
program, and it takes care of running the wgam program twice to do the unweighting.
The script should be modified right at the beginning in case there are any default
variables you need to change. Probably you'll need to change BIN_DIR to point to a directory 
containing a compiled wgam executable i.e. <thisPackageDir>/bin
Then you'll want to change RUN_DIR to a job output directory.


Get started - run a single task
-------------------------------

Within the cards/ directory one datacard is called test.txt

The wgam generator can be run on this by:

run.sh cards/test.txt

This will created a task directory $RUN_DIR/test0, and within this a single job directory job0, in which the wgam executable will be run. When the job finishes it will contain the following:
baur.hbook - the ntuple output file which can be fed into a les houches interface designed to read in this format.
baur.ascii - an alternative ntuple output file which can be fed into a les houches interface designed to read in this format.
baur.txt - a human readable output file - an ascii version of the ntuple data, if output to this is selected in the datacard.
maxwgt - a file showing the convergent history of the maximum weight as it is discovered. This should be checked to see that
the final maximum weight decided upon (the largest value in the file) is not radically different to previous maximums found whilst the events are generated.
cutoffs.txt - a file containing the cross-sections for all events, positive weighted events, and unit events.

It is possible to multiply the number of jobs to create a larger hbook ntuple. So instead, use run.sh with the -m option:

run.sh -m5 cards/test.txt

This will combine the results of running the generator on the test.txt datacard 5 times (5 jobX directories within the task directory). The single baur.hbook file produced at the end
will contain the merged ntuples of the 5 runs. Note again, this does read the datacard an divide the NumberEvents into 5, and then run 5 jobs on that value. It simply runs the same datacard 5 times.
Note that this means the random seed must vary between runs. The run.sh script adds an appropriate entry onto the beginning of the datacard file for each job in order to achieve this (Any subsequent settings of RandomSeed within the datacard file are ignored). 
There is a knock-on effect of changing the RandomSeed between jobs, in that the maxwgt found for each job might be slightly different.

The baurinput.txt file is read such that where there are duplicate parameter entries listed the first one takes priority.
So if the file contains a RandomSeed entry already, this will be ignored.


run multiple tasks
------------------
 
The script also makes it possible to run multiple tasks with varying input (with slightly different datacards each time),
so that you run many tasks with a varying parameter. e.g. you varying the anomalous coupling parameter, of the infrared cutoffs.

A split datacard, involving .template.txt file and a .completions.txt file must be created to do this.

The completions file contains asterisk seperated sections of datacard fragments. These are added to the template file in turn
and each time a new batch job is created with the complete datacard file.

In the cards/ directory two files varycutoffs.template.txt and varycutoffs.completions.txt illustrate this. When specifying the filename
argument for run.sh, it doesn't matter which file you quote.

The tasks can be created by:
run.sh cards/varycutoffs.template.txt
or
run.sh cards/varycutoffs.completions.txt

Or, if it is required to generate larger baur.hbook files within each task, the number of jobs to combine within each can be specified.

run.sh -m5 cards/varycutoffs.template.txt

When this runs it is quite scary because it will set going a large number of batch jobs (numberJobs*numberDatacardsImplied).
The datacard will be different for each task, but within a task, the 5 jobs run use the same datacard, except of course they will vary with a RandomSeed.

Terminology
-----------

Task - within a task one or many jobs work together to produce a single larger ntuple. Each job uses the same datacard, except with a different RandomSeed.
Job - within a task, a job is defined as a double execution of the wgam generator to produce an unweighted event baur.hbook file, to be merged with other hbook files at task level.
Split datacard - a datacard involving a template and a completions file. This is in effect many datacards created by combining a completion with the template. A Task is created for each of the possible datacards created in this way.
